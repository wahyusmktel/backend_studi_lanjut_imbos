<!-- resources/views/admin/partials/footer.blade.php -->
<footer class="footer pl-30 pr-30">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <p>2024 &copy; Studi Lanjut IMBOS Pringsewu.</p>
            </div>
            <div class="col-sm-6 text-right">
                <p>Follow Us</p>
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
                <a href="#"><i class="fa fa-youtube"></i></a>
            </div>
        </div>
    </div>
</footer>
